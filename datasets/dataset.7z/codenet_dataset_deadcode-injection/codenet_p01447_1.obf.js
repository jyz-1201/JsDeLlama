function a0_0x2f71(VaUwNT, key) {
    var stringArray = a0_0x58fa();
    a0_0x2f71 = function (index, key) {
        index = index - 0x0;
        var value = stringArray[index];
        return value;
    };
    return a0_0x2f71(VaUwNT, key);
}
function a0_0x58fa() {
    var _0x242677 = [
        'log',
        'ceil',
        'readFileSync',
        'utf-8'
    ];
    a0_0x58fa = function () {
        return _0x242677;
    };
    return a0_0x58fa();
}
var a0_0x15b717 = a0_0x2f71;
console[a0_0x15b717(0x0)](Math[a0_0x15b717(0x1)](Math[a0_0x15b717(0x0)](+require('fs')[a0_0x15b717(0x2)]('/dev/stdin', a0_0x15b717(0x3))) / Math['log'](0x3)));