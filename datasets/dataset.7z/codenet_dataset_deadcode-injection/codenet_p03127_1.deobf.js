;
var GET = (function () {
    ;
    function f(s) {
        ;
        return new g(s);
    }
    function g(s) {
        ;
        this['_s'] = s.trim().split('\n');
        this['_y'] = 0;
    }
    g.prototype.a = function (f) {
        ;
        var s = this['_s'], y = this['_y'], r;
        if (typeof s[y] === 'string') {
            s[y] = s[y].split(' ').reverse();
        }
        r = s[y].pop();
        if (!s[y].length) {
            this['_y']++;
        }
        return f ? r : +r;
    };
    g.prototype.l = function (f) {
        ;
        var s = this['_s'][this['_y']++].split(' ');
        return f ? s : s.map(a => +a);
    };
    g.prototype.m = function (n, f) {
        ;
        var r = this['_s'].slice(this['_y'], this['_y'] += n).map(a => a.split(' '));
        return f ? r : r.map(a => a.map(a => +a));
    };
    g.prototype.r = function (n, f) {
        ;
        var r = this['_s'].slice(this['_y'], this['_y'] += n);
        return f ? r : r.map(a => +a);
    };
    return f;
}());
;
var o = GET(require('fs').readFileSync('/dev/stdin', 'utf8'));
function gcd(a, b) {
    return b ? gcd(b, a % b) : a;
}
console.log(main());
;
function main() {
    var n = o.a();
    var a = o.l();
    var ans = a[0];
    for (var i = 1; i < n; i++) {
        ans = gcd(ans, a[i]);
    }
    return ans;
}