'use strict';
var a0_0x2da829 = a0_0x41bc;
function main(input) {
    var _0x464945 = a0_0x41bc;
    var line = input[_0x464945(0x0)]('\x20');
    console[_0x464945(0x1)](line[0x2] + '\x20' + line[0x0] + '\x20' + line[0x1]);
}
main(require('fs')[a0_0x2da829(0x2)](a0_0x2da829(0x3), a0_0x2da829(0x4)));
function a0_0x41bc(TdkjVO, key) {
    var stringArray = a0_0x4ef3();
    a0_0x41bc = function (index, key) {
        index = index - 0x0;
        var value = stringArray[index];
        return value;
    };
    return a0_0x41bc(TdkjVO, key);
}
function a0_0x4ef3() {
    var _0x3fbe83 = [
        'split',
        'log',
        'readFileSync',
        '/dev/stdin',
        'utf8'
    ];
    a0_0x4ef3 = function () {
        return _0x3fbe83;
    };
    return a0_0x4ef3();
}