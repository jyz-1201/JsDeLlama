var a0_0x104a05 = a0_0x241a;
function Main(input) {
    var _0x33b577 = a0_0x241a;
    input = input[_0x33b577(0x0)]('\x20');
    tmp = input[0x1][0x0];
    console[_0x33b577(0x1)]('A' + tmp + 'C');
}
function a0_0x5355() {
    var _0x5b5a23 = [
        'split',
        'log',
        '/dev/stdin'
    ];
    a0_0x5355 = function () {
        return _0x5b5a23;
    };
    return a0_0x5355();
}
function a0_0x241a(yoyGzc, key) {
    var stringArray = a0_0x5355();
    a0_0x241a = function (index, key) {
        index = index - 0x0;
        var value = stringArray[index];
        return value;
    };
    return a0_0x241a(yoyGzc, key);
}
Main(require('fs')['readFileSync'](a0_0x104a05(0x2), 'utf8'));