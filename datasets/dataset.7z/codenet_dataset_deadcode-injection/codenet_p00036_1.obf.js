var a0_0x3c9666 = a0_0x3126;
function a0_0x3126(fOlqjO, key) {
    var stringArray = a0_0x3700();
    a0_0x3126 = function (index, key) {
        index = index - 0x0;
        var value = stringArray[index];
        return value;
    };
    return a0_0x3126(fOlqjO, key);
}
function a0_0x3700() {
    var _0x4aebb0 = [
        'readFileSync',
        '/dev/stdin',
        'utf8',
        'trim',
        'split',
        'map',
        'log',
        'indexOf',
        '1101',
        '101',
        '1000001',
        '10000001'
    ];
    a0_0x3700 = function () {
        return _0x4aebb0;
    };
    return a0_0x3700();
}
require('fs')[a0_0x3c9666(0x0)](a0_0x3c9666(0x1), a0_0x3c9666(0x2))[a0_0x3c9666(0x3)]()[a0_0x3c9666(0x4)]('\x0a\x0a')[a0_0x3c9666(0x5)](function (i) {
    var _0x46e963 = a0_0x3126;
    c = i['replace'](/\s/g, '')[_0x46e963(0x4)]('')['join']('');
    console[_0x46e963(0x6)](c['indexOf']('1111') != -0x1 ? 'C' : c[_0x46e963(0x7)]('111') != -0x1 ? 'F' : c[_0x46e963(0x7)](_0x46e963(0x8)) != -0x1 ? 'D' : c[_0x46e963(0x7)](_0x46e963(0x9)) != -0x1 ? 'B' : c['indexOf'](_0x46e963(0xa)) != -0x1 ? 'G' : c[_0x46e963(0x7)](_0x46e963(0xb)) != -0x1 ? 'A' : 'E');
});