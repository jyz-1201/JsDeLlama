'use strict';
;
;
;
var input = require('fs').readFileSync('/dev/stdin', 'utf8');
var cin = input.trim().split(/ |\n/), cid = 0;
console.log(main().toString());
function main() {
    ;
    let n = +cin.shift();
    let a = Array(n);
    let b = Array(n);
    for (let i = 0; i < n; i++) {
        a[i] = +cin.shift();
        b[i] = +cin.shift();
    }
    a = a.sort((x, y) => x - y);
    b = b.sort((x, y) => x - y);
    let min, max;
    if (n % 2 == 0) {
        if (a[n / 2 - 1] != a[n / 2]) {
            min = a[n / 2] - 0.5;
        } else {
            min = a[2 / n];
        }
        if (b[n / 2 - 1] != b[n / 2]) {
            max = b[n / 2 - 1] + 0.5;
        } else {
            max = b[n / 2 - 1];
        }
        return (max - min) * 2 + 1;
    } else {
        min = a[(n - 1) / 2];
        max = b[(n - 1) / 2];
        return max - min + 1;
    }
}