function a0_0x30a2(zBShLG, key) {
    var stringArray = a0_0x39be();
    a0_0x30a2 = function (index, key) {
        index = index - 0x0;
        var value = stringArray[index];
        return value;
    };
    return a0_0x30a2(zBShLG, key);
}
var a0_0x18b83e = a0_0x30a2;
q = [];
function a0_0x39be() {
    var _0x58524a = [
        'readFileSync',
        '/dev/stdin',
        'utf8',
        'trim',
        'split',
        'push',
        'log',
        'pop'
    ];
    a0_0x39be = function () {
        return _0x58524a;
    };
    return a0_0x39be();
}
require('fs')[a0_0x18b83e(0x0)](a0_0x18b83e(0x1), a0_0x18b83e(0x2))[a0_0x18b83e(0x3)]()[a0_0x18b83e(0x4)]('\x0a')['some'](function (i) {
    var _0x17f3b9 = a0_0x30a2;
    i != 0x0 ? q[_0x17f3b9(0x5)](i) : console[_0x17f3b9(0x6)](q[_0x17f3b9(0x7)]());
});