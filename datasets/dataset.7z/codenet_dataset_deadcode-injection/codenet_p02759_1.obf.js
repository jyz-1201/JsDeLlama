'use strict';
const a0_0x519da9 = a0_0x3223;
function a0_0x31ac() {
    const _0x4a41c8 = [
        'split',
        'log',
        'round',
        'readFileSync',
        '/dev/stdin',
        'utf8'
    ];
    a0_0x31ac = function () {
        return _0x4a41c8;
    };
    return a0_0x31ac();
}
function main(input) {
    const _0x25bfc0 = a0_0x3223;
    input = input[_0x25bfc0(0x0)]('\x0a');
    const a = parseInt(input[0x0], 0xa);
    console[_0x25bfc0(0x1)](Math[_0x25bfc0(0x2)](a / 0x2));
}
function a0_0x3223(SYgNwC, key) {
    const stringArray = a0_0x31ac();
    a0_0x3223 = function (index, key) {
        index = index - 0x0;
        let value = stringArray[index];
        return value;
    };
    return a0_0x3223(SYgNwC, key);
}
main(require('fs')[a0_0x519da9(0x3)](a0_0x519da9(0x4), a0_0x519da9(0x5)));