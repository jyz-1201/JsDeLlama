function a0_0x5706(ESvBtm, key) {
    var stringArray = a0_0x5122();
    a0_0x5706 = function (index, key) {
        index = index - 0x0;
        var value = stringArray[index];
        return value;
    };
    return a0_0x5706(ESvBtm, key);
}
function a0_0x5122() {
    var _0x3413a0 = [
        'data',
        'trim',
        'split',
        'log',
        'resume'
    ];
    a0_0x5122 = function () {
        return _0x3413a0;
    };
    return a0_0x5122();
}
var a0_0x5b6274 = a0_0x5706;
process['stdin']['on'](a0_0x5b6274(0x0), function (c) {
    var _0x225abe = a0_0x5706;
    (c + '')[_0x225abe(0x1)]()[_0x225abe(0x2)]('\x0a')['some'](function (n) {
        var _0x1da911 = a0_0x5706;
        for (var d = +n, i = 0x1, a = 0x0, t; t = i++ * d, t < 0x258 ? a += t * t * d : 0x0;);
        console[_0x1da911(0x3)](a);
    });
})[a0_0x5b6274(0x4)]();