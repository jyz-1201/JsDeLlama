const a0_0x4743b8 = a0_0x1500;
function main(s) {
    const _0x13bd75 = a0_0x1500;
    const set = new Set(s[_0x13bd75(0x0)]('\x0a')[0x1][_0x13bd75(0x0)]('\x20'));
    const ans = [...set][_0x13bd75(0x1)] === 0x4 ? _0x13bd75(0x2) : _0x13bd75(0x3);
    console[_0x13bd75(0x4)](ans);
}
function a0_0x1500(EZEVHD, key) {
    const stringArray = a0_0x36cc();
    a0_0x1500 = function (index, key) {
        index = index - 0x0;
        let value = stringArray[index];
        return value;
    };
    return a0_0x1500(EZEVHD, key);
}
function a0_0x36cc() {
    const _0x114418 = [
        'split',
        'length',
        'Four',
        'Three',
        'log',
        'readFileSync',
        '/dev/stdin',
        'utf8'
    ];
    a0_0x36cc = function () {
        return _0x114418;
    };
    return a0_0x36cc();
}
main(require('fs')[a0_0x4743b8(0x5)](a0_0x4743b8(0x6), a0_0x4743b8(0x7)));