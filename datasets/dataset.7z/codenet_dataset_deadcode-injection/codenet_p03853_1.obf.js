var a0_0xaf11c4 = a0_0x5709;
function Main(input) {
    var _0x100a25 = a0_0x5709;
    input = input['trim']();
    var tate = parseInt(input[_0x100a25(0x0)]('\x0a')[0x0]['split']('\x20')[0x0]);
    for (var i = 0x1; i <= tate; i++) {
        console[_0x100a25(0x1)](input[_0x100a25(0x0)]('\x0a')[i]);
        console[_0x100a25(0x1)](input[_0x100a25(0x0)]('\x0a')[i]);
    }
}
function a0_0x5709(cqnULA, key) {
    var stringArray = a0_0x3829();
    a0_0x5709 = function (index, key) {
        index = index - 0x0;
        var value = stringArray[index];
        return value;
    };
    return a0_0x5709(cqnULA, key);
}
function a0_0x3829() {
    var _0xc593d6 = [
        'split',
        'log',
        'readFileSync',
        '/dev/stdin',
        'utf8'
    ];
    a0_0x3829 = function () {
        return _0xc593d6;
    };
    return a0_0x3829();
}
Main(require('fs')[a0_0xaf11c4(0x2)](a0_0xaf11c4(0x3), a0_0xaf11c4(0x4)));