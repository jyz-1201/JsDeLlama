var a0_0x2ccd23 = a0_0x427c;
function a0_0x427c(NxPzZF, key) {
    var stringArray = a0_0x37d4();
    a0_0x427c = function (index, key) {
        index = index - 0x0;
        var value = stringArray[index];
        return value;
    };
    return a0_0x427c(NxPzZF, key);
}
function a0_0x37d4() {
    var _0xc4df48 = [
        'log',
        'readFileSync',
        '/dev/stdin',
        'utf8'
    ];
    a0_0x37d4 = function () {
        return _0xc4df48;
    };
    return a0_0x37d4();
}
console[a0_0x2ccd23(0x0)](Math['pow'](parseInt(require('fs')[a0_0x2ccd23(0x1)](a0_0x2ccd23(0x2), a0_0x2ccd23(0x3)), 0xa), 0x2));