const a0_0x4fc9d9 = a0_0x1b42;
function Main(input) {
    const _0x47e925 = a0_0x1b42;
    c = input;
    const vowel = _0x47e925(0x0);
    console['log'](vowel[_0x47e925(0x1)](c) !== -0x1 ? _0x47e925(0x2) : _0x47e925(0x3));
}
function a0_0x2b66() {
    const _0x3c0e66 = [
        'aeiou',
        'indexOf',
        'vowel',
        'consonant',
        'readFileSync',
        '/dev/stdin'
    ];
    a0_0x2b66 = function () {
        return _0x3c0e66;
    };
    return a0_0x2b66();
}
function a0_0x1b42(tmaGbW, key) {
    const stringArray = a0_0x2b66();
    a0_0x1b42 = function (index, key) {
        index = index - 0x0;
        let value = stringArray[index];
        return value;
    };
    return a0_0x1b42(tmaGbW, key);
}
Main(require('fs')[a0_0x4fc9d9(0x4)](a0_0x4fc9d9(0x5), 'utf8'));