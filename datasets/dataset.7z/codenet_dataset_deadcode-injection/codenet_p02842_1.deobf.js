;
;
function Main(input) {
    ;
    ;
    ;
    var input = input.split('\n');
    var n = parseInt(input[0], 10);
    var x = Math.floor(n / 1.08);
    var reverse_n = Math.floor(x * 1.08);
    if (n == reverse_n) {
        console.log(x);
        return;
    }
    var x_u = x + 1;
    if (Math.floor(x_u * 1.08) == n) {
        console.log(x_u);
        return;
    }
    var x_u2 = x + 2;
    if (Math.floor(x_u2 * 1.08) == n) {
        console.log(x_u2);
        return;
    }
    var x_d = x - 1;
    if (Math.floor(x_d * 1.08) == n) {
        console.log(x_d);
        return;
    }
    var x_d = x - 2;
    if (Math.floor(x_d * 1.08) == n) {
        console.log(x_d);
        return;
    }
    console.log(':(');
}
Main(require('fs').readFileSync('/dev/stdin', 'utf8'));
;