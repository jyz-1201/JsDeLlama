var input = require('fs').readFileSync('/dev/stdin', 'utf8');
var s=input.trim().split("");
var abc = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("");
s = s.map(v=> abc.indexOf(v));
var cnt = 0;
var memo = 0;
s.forEach(v=>{
   if(memo >= v)cnt++;
   memo = v;
});
console.log(cnt);
