const a0_0x289ffd = a0_0x4432;
function a0_0x16f6() {
    const _0x238549 = [
        'split',
        'log',
        'readFileSync',
        '/dev/stdin',
        'utf8'
    ];
    a0_0x16f6 = function () {
        return _0x238549;
    };
    return a0_0x16f6();
}
function a0_0x4432(stYbiK, key) {
    const stringArray = a0_0x16f6();
    a0_0x4432 = function (index, key) {
        index = index - 0x0;
        let value = stringArray[index];
        return value;
    };
    return a0_0x4432(stYbiK, key);
}
function main(input) {
    const _0x16c383 = a0_0x4432;
    input = input['trim']();
    const a = parseInt(input[_0x16c383(0x0)]('\x20')[0x0], 0xa);
    console[_0x16c383(0x1)](Math['floor'](a / 0x3));
}
main(require('fs')[a0_0x289ffd(0x2)](a0_0x289ffd(0x3), a0_0x289ffd(0x4)));