var a0_0x2f355c = a0_0x3ae4;
var input = require('fs')['readFileSync'](a0_0x2f355c(0x0), 'utf8');
function a0_0x3ae4(XVGDHB, key) {
    var stringArray = a0_0x2086();
    a0_0x3ae4 = function (index, key) {
        index = index - 0x0;
        var value = stringArray[index];
        return value;
    };
    return a0_0x3ae4(XVGDHB, key);
}
var arr = input[a0_0x2f355c(0x1)]()['split']('\x0a');
var x = arr[a0_0x2f355c(0x2)]() - 0x0;
console[a0_0x2f355c(0x3)](a0_0x2f355c(0x4) + '3'[a0_0x2f355c(0x5)](x / 0x64));
function a0_0x2086() {
    var _0x28d5f5 = [
        '/dev/stdin',
        'trim',
        'shift',
        'log',
        'ai1333',
        'repeat'
    ];
    a0_0x2086 = function () {
        return _0x28d5f5;
    };
    return a0_0x2086();
}