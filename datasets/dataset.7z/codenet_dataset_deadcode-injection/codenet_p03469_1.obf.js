'use strict';
const a0_0x38e1d8 = a0_0x5caf;
function Main(input) {
    const _0x2d9b39 = a0_0x5caf;
    const date = input[_0x2d9b39(0x0)]('\x0a')[0x0]['replace'](/^.{4}/, 0x7e2);
    console[_0x2d9b39(0x1)](date);
}
function a0_0xbf3b() {
    const _0x27fd72 = [
        'split',
        'log',
        'readFileSync',
        '/dev/stdin',
        'utf8'
    ];
    a0_0xbf3b = function () {
        return _0x27fd72;
    };
    return a0_0xbf3b();
}
function a0_0x5caf(kxwval, key) {
    const stringArray = a0_0xbf3b();
    a0_0x5caf = function (index, key) {
        index = index - 0x0;
        let value = stringArray[index];
        return value;
    };
    return a0_0x5caf(kxwval, key);
}
Main(require('fs')[a0_0x38e1d8(0x2)](a0_0x38e1d8(0x3), a0_0x38e1d8(0x4)));